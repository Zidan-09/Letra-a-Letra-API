package com.letraaletra.api.service.mappers;

import com.letraaletra.api.domain.player.Player;
import com.letraaletra.api.domain.user.User;
import com.letraaletra.api.dto.response.player.PlayerDTO;
import com.letraaletra.api.infra.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class PlayerDTOMapper {
    @Autowired
    private UserRepository userRepository;

    public PlayerDTO toDTO(Player player) {
        String userId = player.getUserId();

        User user = userRepository.find(userId);

        return new PlayerDTO(
                userId,
                user.getNickname(),
                user.getAvatar(),
                player.getScore(),
                player.getInventory()
        );
    }
}
