package com.letraaletra.api.service;

import com.letraaletra.api.domain.Game;
import com.letraaletra.api.domain.GameState;
import com.letraaletra.api.domain.game.GameSettings;
import com.letraaletra.api.domain.participant.Participant;
import com.letraaletra.api.domain.participant.ParticipantRole;
import com.letraaletra.api.domain.user.User;
import com.letraaletra.api.dto.response.game.GameDTO;
import com.letraaletra.api.dto.response.websocket.GameStartedWsResponse;
import com.letraaletra.api.dto.response.websocket.GameUpdatedWsResponse;
import com.letraaletra.api.dto.response.websocket.WsResponseDTO;
import com.letraaletra.api.exception.exceptions.GameNotFoundException;
import com.letraaletra.api.exception.exceptions.OnlyHostCanStart;
import com.letraaletra.api.exception.exceptions.UserNotFound;
import com.letraaletra.api.infra.repository.GameRepository;
import com.letraaletra.api.infra.repository.SessionRepository;
import com.letraaletra.api.infra.repository.UserRepository;
import com.letraaletra.api.service.mappers.GameDTOMapper;
import com.letraaletra.api.service.mappers.GameStateDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import tools.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Service
public class GameService {
    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private SessionRepository sessionRepository;

    @Autowired
    private GameDTOMapper gameDTOMapper;

    @Autowired
    private GameStateDTOMapper gameStateDTOMapper;

    @Autowired
    private GameStateService gameStateService;

    @Autowired
    private ObjectMapper objectMapper;

    public void createGame(String name, GameSettings gameSettings, String userId, String sessionId) {
        String gameId = UUID.randomUUID().toString();

        User user = userRepository.find(userId);

        if (user == null) {
            throw new UserNotFound();
        }

        Participant host = new Participant(
                userId,
                sessionId,
                user.getNickname(),
                user.getAvatar(),
                ParticipantRole.PLAYER
        );

        Game game = new Game(gameId, name, gameSettings, host);

        gameRepository.save(game);

        GameUpdatedWsResponse data = new GameUpdatedWsResponse(
                gameDTOMapper.toDTO(game)
        );

        broadCast(gameId, data);
    }

    public void joinGame(String tokenGameId, String sessionId) {
        String gameId = tokenService.getTokenContent(tokenGameId);

        Game game = gameRepository.find(gameId);

        WebSocketSession session = sessionRepository.find(sessionId);

        if (session == null) {
            throw new UserNotFound();
        }

        String tokenUserId = (String) session.getAttributes().get("token");

        if (tokenUserId == null) {
            throw new UserNotFound();
        }

        String userId = tokenService.getTokenContent(tokenUserId);

        User user = userRepository.find(userId);

        if (user == null) {
            throw new UserNotFound();
        }

        Participant participant = new Participant(
                userId,
                sessionId,
                user.getNickname(),
                user.getAvatar(),
                ParticipantRole.PLAYER
        );

        game.participantJoinGame(participant);

        GameUpdatedWsResponse data = new GameUpdatedWsResponse(
                gameDTOMapper.toDTO(game)
        );

        broadCast(gameId, data);
    }

    public void startGame(String tokenGameId, String sessionId) {
        String gameId = tokenService.getTokenContent(tokenGameId);

        Game game = gameRepository.find(gameId);

        String hostId = game.getGameSettings().getHostId();
        Participant participant = game.getParticipants().stream()
                .filter(p -> p.getSocketId().equals(sessionId))
                .findFirst()
                .orElse(null);

        if (participant == null) {
            throw new UserNotFound();
        }

        if (!participant.getSocketId().equals(hostId)) {
            throw new OnlyHostCanStart();
        }

        GameState gameState = gameStateService.generateGameState(game);

        game.updateGameState(gameState);

        GameStartedWsResponse data = new GameStartedWsResponse(
                gameStateDTOMapper.toDTO(gameState)
        );

        broadCast(gameId, data);
    }

    public Game findById(String gameId) {
        Game game = gameRepository.find(gameId);

        if (game == null) {
            throw new GameNotFoundException();
        }

        return game;
    }

    private void broadCast(String gameId, WsResponseDTO dto) {
        Game game = gameRepository.find(gameId);

        if (game == null) {
            throw new GameNotFoundException();
        }

        String json = objectMapper.writeValueAsString(dto);

        for (Participant participant : game.getParticipants()) {
            WebSocketSession session = sessionRepository.find(participant.getSocketId());

            if (session == null) {
                continue;
            }

            if (!session.isOpen()) {
                sessionRepository.remove(session);
                continue;
            }

            try {
                session.sendMessage(new TextMessage(json));
            } catch (IOException e) {
                System.out.println("Error to send message to" + session.getId() + ": " + e.getMessage());
            }
        }
    }

    public List<GameDTO> getGames() {
        return gameRepository.get().stream()
                .map(g -> gameDTOMapper.toDTO(g))
                .toList();
    }
}
