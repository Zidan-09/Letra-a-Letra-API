package com.letraaletra.api.service.mappers;

import com.letraaletra.api.domain.Game;
import com.letraaletra.api.domain.participant.Participant;
import com.letraaletra.api.dto.response.game.GameDTO;
import com.letraaletra.api.service.TokenService;
import org.springframework.beans.factory.annotation.Autowired;

public class GameDTOMapper {
    @Autowired
    private TokenService tokenService;

    public GameDTO toDTO(Game game) {
        String tokenGameId = tokenService.generateToken(game.getId());

        return new GameDTO(
                tokenGameId,
                game.getRoomName(),
                game.getParticipants().stream().map(Participant::getParticipantToSend).toList()
        );
    }
}
