package com.letraaletra.api.service.mappers;

import com.letraaletra.api.domain.GameState;
import com.letraaletra.api.dto.response.game.BoardDTO;
import com.letraaletra.api.dto.response.game.GameStateDTO;
import com.letraaletra.api.dto.response.player.PlayerDTO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class GameStateDTOMapper {

    @Autowired
    private PlayerDTOMapper playerDTOMapper;

    @Autowired
    private BoardDTOMapper boardDTOMapper;

    public GameStateDTO toDTO(GameState gameState) {
        List<PlayerDTO> playerDTOS = gameState.getPlayers().values()
                .stream().map(p -> playerDTOMapper.toDTO(p))
                .toList();

        BoardDTO[][] boardDTO = boardDTOMapper.toDTO(gameState.getBoard());

        return new GameStateDTO(
                playerDTOS,
                boardDTO,
                gameState.currentPlayerTurn()
        );
    }
}
