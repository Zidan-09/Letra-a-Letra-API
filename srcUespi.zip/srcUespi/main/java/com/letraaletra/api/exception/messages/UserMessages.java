package com.letraaletra.api.exception.messages;

import com.letraaletra.api.exception.MessageCode;

public enum UserMessages implements MessageCode {
    USER_CREATED("user_created"),
    USER_UPDATED("user_updated"),
    USER_DELETED("user_deleted"),

    USER_FOUND("user_found"),
    USERS_FOUND("users_found"),
    USER_NOT_FOUND("user_not_found"),

    USER_ALREADY_EXISTS("user_already_exists"),
    EMAIL_ALREADY_IN_USE("email_already_in_use"),
    USERNAME_ALREADY_IN_USE("username_already_in_use"),

    INVALID_CREDENTIALS("invalid_credentials"),
    USER_DISABLED("user_disabled"),
    USER_BLOCKED("user_blocked"),

    USER_ALREADY_IN_GAME("user_already_in_game"),

    INVALID_USER_DATA("invalid_user_data");

    private final String message;

    UserMessages(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
