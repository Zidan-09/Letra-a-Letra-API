package com.letraaletra.api.dto.request.user;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateUserRequestDTO(
        @NotBlank(message = "invalid_input")
        String nickname,

        @NotBlank(message = "invalid_input")
        String avatar,

        @NotBlank(message = "invalid_input")
        @Email(message = "invalid_email")
        String email,

        @NotBlank(message = "invalid_input")
        @Size(min = 8, message = "invalid_password")
        String password
) {
}
