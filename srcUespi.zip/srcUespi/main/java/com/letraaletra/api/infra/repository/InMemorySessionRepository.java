package com.letraaletra.api.infra.repository;

import org.springframework.web.socket.WebSocketSession;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class InMemorySessionRepository implements SessionRepository {

    private final Map<String, WebSocketSession> sessionMap = new ConcurrentHashMap<>();

    @Override
    public void save(WebSocketSession webSocketSession) {
        sessionMap.put(webSocketSession.getId(), webSocketSession);
    }

    @Override
    public WebSocketSession find(String sessionId) {
        return sessionMap.get(sessionId);
    }

    @Override
    public void remove(WebSocketSession webSocketSession) {
        sessionMap.remove(webSocketSession.getId());
    }
}