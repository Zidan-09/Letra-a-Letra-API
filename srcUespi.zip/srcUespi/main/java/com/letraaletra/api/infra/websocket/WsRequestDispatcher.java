package com.letraaletra.api.infra.websocket;

import com.letraaletra.api.dto.request.websocket.*;
import com.letraaletra.api.exception.exceptions.InvalidPlayerActionException;
import com.letraaletra.api.infra.repository.SessionRepository;
import com.letraaletra.api.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.socket.WebSocketSession;

public class WsRequestDispatcher {
    @Autowired
    private GameService gameService;

    @Autowired
    private SessionRepository sessionRepository;

    public void dispatcher(WsRequestDTO request, WebSocketSession session) {
        switch (request) {
            case CreateGameWsRequest create -> handleCreate(create, session);
            case JoinGameWsRequest join -> handleJoin(join, session);
            case StartGameWsRequest start -> handleStart(start, session);
            case PlayerActionWsRequest playerAction -> handlePlayerAction(playerAction);
            default -> throw new InvalidPlayerActionException();
        }
    }

    private void handleCreate(CreateGameWsRequest request, WebSocketSession session) {
        gameService.createGame(
                request.name(),
                request.gameSettings(),
                session.getId(),
                (String) session.getAttributes().get("token")
        );
    }

    private void handleJoin(JoinGameWsRequest request, WebSocketSession session) {
        gameService.joinGame(
                request.tokenGameId(),
                session.getId()
        );
    }

    private void handleStart(StartGameWsRequest request, WebSocketSession session) {
        gameService.startGame(
                request.tokenGameId(),
                session.getId()
        );
    }

    private void handlePlayerAction(PlayerActionWsRequest request) {

    }
}
