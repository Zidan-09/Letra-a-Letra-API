package com.letraaletra.api.service;

import com.letraaletra.api.domain.board.Board;
import com.letraaletra.api.domain.game.GameMode;
import com.letraaletra.api.domain.theme.Theme;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BoardServiceTest {

    @InjectMocks
    private BoardService boardService;

    @Test
    @DisplayName("Should return an Board without any exception")
    void createBoard() {
        Theme theme = new Theme("test", List.of("test1", "test2", "test3", "test4", "test5"));
        Board board = boardService.createBoard(theme, GameMode.NORMAL);

        assertNotNull(board);
    }
}